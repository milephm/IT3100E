package hust.soict.ict.test.screen;

public class StoreTest {
    public static void main(String[] args) {
    }
}
