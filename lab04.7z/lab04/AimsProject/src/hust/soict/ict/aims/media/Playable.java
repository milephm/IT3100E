package hust.soict.ict.aims.media;

public interface Playable {
    public void play();
}
